# Creative WP Shop Theme
Creative WP is base on WooCommerce and Storefront theme to build a new custom made WooCommerce theme.

# Course
Udemy:
<h2><a href="https://www.udemy.com/course/hosourcewordpress/" target="_blank">https://www.udemy.com/course/hosourcewordpress</a></h2>

腾讯课堂：
<h2><a href="https://ke.qq.com/course/448367?tuin=b26eb164" target="_blank">https://ke.qq.com/course/448367</a></h2>

# Creative WP Shop Theme detail
Theme Name:   Creative WP V1.0 <br/>
Demo URI:     http://www.code202007zh.demo.creative.chat <br/>
Author:       Creative Source <br/>
Author URI:   http://creative.chat <br/>

<center><img src="https://raw.githubusercontent.com/creative-chat/Creative-WP-Theme/master/screenshot.png"></center>

# Version Update
Version 1.0: 2020-07-08